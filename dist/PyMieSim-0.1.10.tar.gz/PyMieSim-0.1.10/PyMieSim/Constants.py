from scipy.constants import c, mu_0 as mu0, epsilon_0 as eps0
