"""
Sphere: coherent coupling vs sampling
=====================================

"""

# %%
# Importing the package dependencies: numpy, PyMieSim
import numpy
from PyMieSim.units import ureg

from PyMieSim.experiment.detector import CoherentMode
from PyMieSim.experiment.scatterer import Sphere
from PyMieSim.experiment.source import Gaussian
from PyMieSim.experiment import Setup
from PyOptik import Material

source = Gaussian(
    wavelength=400 * ureg.nanometer,
    polarization=90 * ureg.degree,
    optical_power=1e-3 * ureg.watt,
    NA=0.2 * ureg.AU,
)
scatterer = Sphere(
    diameter=5000 * ureg.nanometer,
    refractive_index=Material.BK7,
    medium_refractive_index=1 * ureg.RIU,
    source=source,
)

detector = CoherentMode(
    mode_number=["LP01"],
    rotation=[0] * ureg.degree,
    NA=[0.1] * ureg.AU,
    phi_offset=numpy.linspace(-20, 20, 200) * ureg.degree,
    gamma_offset=[0] * ureg.degree,
    sampling=[10, 20, 40, 80, 160, 500] * ureg.AU,
    polarization_filter=[0] * ureg.degree,
)

experiment = Setup(scatterer=scatterer, source=source, detector=detector)

dataframe = experiment.get("coupling")

dataframe.plot(x="detector:phi_offset")
