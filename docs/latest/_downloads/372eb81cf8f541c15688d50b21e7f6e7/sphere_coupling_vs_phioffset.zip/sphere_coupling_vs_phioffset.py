"""
Sphere: Goniometer
==================

"""

# %%
# Importing the package dependencies: numpy, PyMieSim
from PyMieSim.units import ureg
import numpy

from PyMieSim.experiment.detector import Photodiode, CoherentMode
from PyMieSim.experiment.scatterer import Sphere
from PyMieSim.experiment.source import Gaussian
from PyMieSim.experiment import Setup
from PyMieSim.single.polarization import RightCircular
from PyOptik import Material

source = Gaussian(
    wavelength=1200 * ureg.nanometer,
    polarization=RightCircular(),
    optical_power=1e-3 * ureg.watt,
    NA=0.2 * ureg.AU,
)
scatterer = Sphere(
    diameter=20 * ureg.nanometer,
    refractive_index=Material.BK7,
    medium_refractive_index=1 * ureg.RIU,
    source=source,
)

detector = Photodiode(
    NA=[0.1, 0.2] * ureg.AU,
    phi_offset=numpy.linspace(-180, 180, 200) * ureg.degree,
    cache_NA=0.05 * ureg.AU,
    gamma_offset=0 * ureg.degree,
    sampling=400 * ureg.AU,
)

experiment = Setup(scatterer=scatterer, source=source, detector=detector)

dataframe = experiment.get("coupling")

dataframe.plot(x="detector:phi_offset")
