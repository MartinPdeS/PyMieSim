"""
SPF Computation
===============

This example demonstrates the computation and visualization of the Scattering Phase Function (SPF) using PyMieSim.
"""

from PyMieSim import (
    ureg,
    CoreShell,
    Gaussian,
    Simulation,
    PolarizationState,
)



polarization = PolarizationState(angle=90 * ureg.degree)

source = Gaussian(
    wavelength=1000 * ureg.nanometer,
    polarization=polarization,
    optical_power=1 * ureg.watt,
    numerical_aperture=0.3,
)


scatterer = CoreShell(
    core_diameter=300 * ureg.nanometer,
    shell_thickness=10 * ureg.nanometer,
    core_material=1.48,
    shell_material=1.38,
    medium=1.33,
)

setup = Simulation(
    scatterer=scatterer,
    source=source,
)

spf = setup.spf(sampling=100)

figure = spf.plot()
