"""
Sphere: Coupling vs polarization filter
=======================================
"""

# %%
# Importing the package dependencies: numpy, PyMieSim
import numpy as np
from PyMieSim.units import ureg

from PyMieSim.experiment.detector import Photodiode
from PyMieSim.experiment.scatterer import Sphere
from PyMieSim.experiment.source import Gaussian
from PyMieSim.experiment import Setup
from PyOptik import Material

source = Gaussian(
    wavelength=[950, 1050] * ureg.nanometer,
    polarization=0 * ureg.degree,
    optical_power=[1e-3] * ureg.watt,
    NA=0.2 * ureg.AU,
)


scatterer = Sphere(
    diameter=np.linspace(100, 2000, 20) * ureg.nanometer,
    refractive_index=[Material.BK7, Material.water],
    medium_refractive_index=1 * ureg.RIU,
    source=source,
)

detector = Photodiode(
    NA=[0.1] * ureg.AU,
    phi_offset=-180 * ureg.degree,
    gamma_offset=0 * ureg.degree,
    polarization_filter=np.linspace(-180, 180, 100) * ureg.degree,
    sampling=[500] * ureg.AU,
)

experiment = Setup(scatterer=scatterer, source=source, detector=detector)

dataframe = experiment.get("coupling")

dataframe.plot(x="detector:polarization_filter", std="scatterer:diameter")
