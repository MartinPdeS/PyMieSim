"""
Samples Properties
==================
"""

from PyMieSim import (
    ureg,
    Sphere,
    Gaussian,
    PolarizationState,
)


polarization_state = PolarizationState(angle=0 * ureg.degree)

source = Gaussian(
    wavelength=1000 * ureg.nanometer,
    polarization=polarization_state,
    optical_power=1 * ureg.watt,
    numerical_aperture=0.3,
)

scatterer = Sphere(
    diameter=800 * ureg.nanometer,
    material=1.4,
    medium=1.0,
)

scatterer.init(source)

scatterer.print_properties(4)
