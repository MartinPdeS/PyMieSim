"""
InfiniteCylinder: Qsca vs wavelength std
========================================

"""

# %%
# Importing the package dependencies: numpy, PyMieSim
import numpy as np
from PyMieSim.units import ureg

from PyMieSim.experiment.scatterer import InfiniteCylinder
from PyMieSim.experiment.source import Gaussian, PolarizationSet
from PyMieSim.experiment import Setup
from PyOptik import Material

polarization_set = PolarizationSet(
    angles=[0.0] * ureg.degree,
)

source = Gaussian(
    wavelength=np.linspace(200, 1800, 300) * ureg.nanometer,
    polarization=polarization_set,
    optical_power=1 * ureg.watt,
    numerical_aperture=0.2 * ureg.AU,
)
scatterer = InfiniteCylinder(
    diameter=np.linspace(400, 1400, 10) * ureg.nanometer,
    refractive_index=Material.silver,
    medium_refractive_index=1 * ureg.RIU,
    source=source,
)

experiment = Setup(scatterer=scatterer, source=source)

dataframe = experiment.get("Qsca")

dataframe.plot(x="source:wavelength", std="scatterer:diameter")
