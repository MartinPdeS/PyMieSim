"""
Core-Shell Particles: 1
=======================

"""

# Standard library imports
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PyMieSim import (
    ureg,
    CoreShellSet,
    GaussianSet,
    PolarizationSet,
    Experiment,
)

# PyMieSim imports
from PyMieSim.directories import validation_data_path

# Define parameters
wavelength = 600 * ureg.nanometer
polarization = PolarizationSet(angles=0 * ureg.degree)
optical_power = 1 * ureg.watt
NA = 0.2
medium_index = 1.0
core_index = 1.5
shell_index = 1.4
shell_thickness = 600 * ureg.nanometer
core_diameters = np.geomspace(10, 500, 400) * ureg.nanometer

# Configure the Gaussian source
source = GaussianSet(
    wavelength=[600] * ureg.nanometer,
    polarization=polarization,
    optical_power=[1] * ureg.watt,
    numerical_aperture=[0.2]
)

# Setup core-shell scatterer
scatterer = CoreShellSet(
    core_diameter=core_diameters,
    shell_thickness=shell_thickness,
    core_material=[1.5],
    shell_material=[1.4],
    medium=[1.0],
)

# Create experimental setup
experiment = Experiment(scatterer_set=scatterer, source_set=source)

comparison_measures = ["Qsca", "Qext", "Qabs", "g", "Qpr", "Qback"]

# Simulate using PyMieSim
pymiesim = experiment.get(*comparison_measures, as_numpy=True)

pymiescatt_dataframe = pd.read_csv(
    validation_data_path / "pymiescatt/example_coreshell_1.csv"
)

figure, ax = plt.subplots(1, 1)


for string in comparison_measures:
    ax.plot(
        pymiescatt_dataframe["core_diameter"],
        pymiescatt_dataframe[string],
        label="PyMieScatt: " + string,
        linewidth=3,
    )


for data, string in zip(pymiesim, comparison_measures):
    ax.plot(
        core_diameters.to(ureg.nanometer).magnitude,
        data,
        label="PyMieSim: " + string,
        linestyle="--",
        color="black",
        linewidth=1.5,
    )


ax.set(
    xlabel="Core Diameter (μm)",
    ylabel="Scattering Efficiency",
    title="Comparison of Scattering Efficiency for Core-Shell Particles",
)
plt.legend()
plt.show()
