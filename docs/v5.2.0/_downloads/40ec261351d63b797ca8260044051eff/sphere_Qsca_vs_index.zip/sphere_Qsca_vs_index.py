"""
Sphere: Qsca vs index
=====================

"""
import numpy as np
from PyMieSim import (
    ureg,
    SphereSet,
    GaussianSet,
    PolarizationSet,
    Experiment,
)


polarization_set = PolarizationSet(
    angles=[30.0] * ureg.degree,
)

source = GaussianSet(
    wavelength=[500.0, 1000.0, 1500.0] * ureg.nanometer,
    polarization=polarization_set,
    optical_power=[1e-3] * ureg.watt,
    numerical_aperture=[0.2],
)

scatterer = SphereSet(
    diameter=[800.0] * ureg.nanometer,
    material=np.linspace(1.3, 1.9, 100),
    medium=[1.0],
)

experiment = Experiment(scatterer_set=scatterer, source_set=source)

result = experiment.get("Qsca")

result.plot(x="scatterer:material")
