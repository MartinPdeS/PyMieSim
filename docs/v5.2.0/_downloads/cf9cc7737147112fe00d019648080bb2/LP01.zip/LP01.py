"""
LP01 Mode Detector
==================

This example demonstrates the initialization and visualization of an LP01 Mode detector using PyMieSim.
"""

from PyMieSim import (
    ureg,
    Sphere,
    Gaussian,
    PolarizationState,
    CoherentMode,
    Simulation,
)



polarization_state = PolarizationState(
    angle=0 * ureg.degree,
)

source = Gaussian(
    wavelength=1550 * ureg.nanometer,
    polarization=polarization_state,
    optical_power=1 * ureg.watt,
    numerical_aperture=0.3,
)

scatterer = Sphere(
    diameter=1800 * ureg.nanometer,
    medium=1.0,
    material=1.5,
)

detector = CoherentMode(
    mode_number="LP01",
    numerical_aperture=0.2,
    gamma_offset=0 * ureg.degree,
    phi_offset=30 * ureg.degree,
    rotation=0 * ureg.degree,
    polarization_filter=0 * ureg.degree,
    medium=1.0,
)

setup = Simulation(scatterer=scatterer, source=source, detector=detector)

setup.plot_system()
