"""
Scattering efficiency of a sphere
=================================

PyMieSim makes it easy to create a source and a scatterer. With these objects
defined, it is possible to use PyMieSim to find the scattering efficiency of the
scatterer. This feature can be used to plot a graph of the scattering efficiency
of a sphere as a function of the permittivity and the size parameter.
"""

import numpy
from PyMieSim import (
    Measure,
    ureg,
    SphereSet,
    GaussianSet,
    PolarizationSet,
    Experiment,
)
import matplotlib.pyplot as plt


polarization_state = PolarizationSet(
    angles=90 * ureg.degree,
)

permitivity = numpy.linspace(-10, 50, 400)

index = numpy.sqrt(permitivity.astype(complex))

diameter = numpy.linspace(1, 200, 400) * ureg.nanometer

source = GaussianSet(
    wavelength=[400] * ureg.nanometer,
    polarization=polarization_state,
    optical_power=[1e-3] * ureg.watt,
    numerical_aperture=[0.2],
)

scatterer = SphereSet(
    diameter=diameter,
    material=index,
    medium=[1]
)

experiment = Experiment(scatterer_set=scatterer, source_set=source)

data = experiment.get(Measure.QSCA).as_numpy()

figure, ax = plt.subplots(1, 1)
ax.set(
    xlabel="Permittivity",
    ylabel=r"Diameter [$\mu$ m]",
    title="Scattering efficiency of a sphere",
)

image = ax.pcolormesh(permitivity, diameter, numpy.log(data))

plt.colorbar(mappable=image)

plt.show()
